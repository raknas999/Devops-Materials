![hero](./design-drafts/hero-3.png)

<br />

# Golden Guide to Kubernetes Application Development

First of all, thanks for purchasing the upgraded package for the Golden Guide to Kubernetes Application Development!

## All the bonus content

You’ve unlocked access to a wide array of extra content contained in each directory in this repo.

📖 `book` — the **complete book content** in both PDF and source formats, plus revision history of each PDF export

⏳ `practice-exam` — a thirty question, three hour **practice exam** with complete solutions to get you ready for your real CKAD exam

🖥️ `example-code` — **full code examples** used in the book, plus extra utilities

🎨 `diagrams` — **high resolution source diagrams** from the book

📝 `design-drafts` — behind the scenes **design resources**, covers, and experiments

<br />

In addition to the extra content, you've also unlocked access to a  **community** of developers all preparing for the CKAD exam. You can ask questions of people who have taken the exam, and study alongside other developers as you prepare.

I'd encourage you to **actively participate, ask questions, and share knowledge** via Issues raised in this repo. You can ask me questions directly, get help debugging, or make suggestions for the book. You are also welcome to open a **Pull Request** if you’d like to contribute.

As always, feel free to email me directly at matt@matthewpalmer.net.

## Let me know 

I'm super excited to hear about your exam – good or bad. I want to make this book and upgraded content as effective as possible for preparing developers in learning Kubernetes.
